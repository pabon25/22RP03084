import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;

public class viewCart extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><head><title>View Cart</title>");
        out.println("<link rel='stylesheet' type='text/css' href='styles.css'>");
        out.println("</head><body>");
        out.println("<footer class=\"footer\">\n" +
"        <p>&copy; 2024 Masengesho Pacifique. All rights reserved.</p>\n" +
"    </footer>");
        out.println("<div class='container'>");
        out.println("<h1>Your Cart</h1>");
        
        Cookie cartCookie = getCookie(request, "cart");
        if (cartCookie != null && cartCookie.getValue() != null && !cartCookie.getValue().isEmpty()) {
            String cart = URLDecoder.decode(cartCookie.getValue(), StandardCharsets.UTF_8.name());
            String[] items = cart.split(",");
            out.println("<ul>");
            for (String item : items) {
                if (!item.isEmpty()) {
                    out.println("<li>" + item + "</li>");
                }
            }
            out.println("</ul>");
        } else {
            out.println("<p>Your cart is empty.</p>");
        }

        out.println("<div class='nav'>");
        out.println("<a href='addform.html'>Add Item</a> | ");
        out.println("<a href='removeform.html'>Remove Item</a> | ");
        out.println("<a href='clearform.html'>Clear Cart</a>");
        out.println("</div>");
        out.println("</div>");
        out.println("</body></html>");
    }

    private Cookie getCookie(HttpServletRequest request, String name) {
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals(name)) {
                    return cookie;
                }
            }
        }
        return null;
    }
}
