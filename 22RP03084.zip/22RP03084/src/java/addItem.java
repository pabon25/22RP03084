import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.net.URLEncoder;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;

public class addItem extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String itemName = request.getParameter("item");
        if (itemName != null && !itemName.isEmpty()) {
            Cookie cartCookie = getCookie(request, "cart");
            String cart = cartCookie != null ? URLDecoder.decode(cartCookie.getValue(), StandardCharsets.UTF_8.name()) : "";
            cart += itemName + ",";
            Cookie newCartCookie = new Cookie("cart", URLEncoder.encode(cart, StandardCharsets.UTF_8.name()));
            newCartCookie.setMaxAge(86400); // 1 day
            response.addCookie(newCartCookie);
        }
        response.sendRedirect("viewCart");
    }

    private Cookie getCookie(HttpServletRequest request, String name) {
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals(name)) {
                    return cookie;
                }
            }
        }
        return null;
    }
}
