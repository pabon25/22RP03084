import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;

public class clearCart extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie cartCookie = new Cookie("cart", "");
        cartCookie.setMaxAge(0); // Delete the cookie
        response.addCookie(cartCookie);
        response.sendRedirect("viewCart");
    }
}
