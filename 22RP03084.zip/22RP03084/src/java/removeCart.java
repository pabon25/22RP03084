import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.stream.Collectors;

public class removeCart extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String itemName = request.getParameter("item");
        Cookie cartCookie = getCookie(request, "cart");
        if (cartCookie != null && itemName != null && !itemName.isEmpty()) {
            String cart = URLDecoder.decode(cartCookie.getValue(), StandardCharsets.UTF_8.name());
            String newCart = Arrays.stream(cart.split(","))
                    .filter(item -> !item.equals(itemName) && !item.isEmpty())
                    .collect(Collectors.joining(","));
            Cookie newCartCookie = new Cookie("cart", URLEncoder.encode(newCart, StandardCharsets.UTF_8.name()));
            newCartCookie.setMaxAge(60 * 60 * 24); // 1 day
            response.addCookie(newCartCookie);
        }
        response.sendRedirect("viewCart");
    }

    private Cookie getCookie(HttpServletRequest request, String name) {
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals(name)) {
                    return cookie;
                }
            }
        }
        return null;
    }
}
